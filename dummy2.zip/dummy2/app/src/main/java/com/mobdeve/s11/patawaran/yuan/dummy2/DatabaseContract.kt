package com.mobdeve.s11.patawaran.yuan.dummy2

object DatabaseContract {
    // Define your database schema here
    object PostEntry {
        const val TABLE_NAME = "posts"
        const val COLUMN_CAPTION = "caption"
        const val COLUMN_LOCATION = "location"
        const val COLUMN_SCREENSHOT = "screenshot"
        // Add other columns as needed
    }
}
